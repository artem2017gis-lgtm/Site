export {default} from '../pages/admin/AdminDoctors';
