<?php
namespace App\Http\Controllers\Admin;
use App\Models\Review; use Illuminate\Http\Request;
class ReviewController extends \App\Http\Controllers\Controller {public function index(Request $r){return Review::with(['doctor','patient'])->when($r->published!==null,fn($q)=>$q->where('is_published',(bool)$r->published))->latest()->paginate(20);} public function update(Request $r,Review $review){$review->update($r->validate(['is_published'=>'required|boolean']));return $review->load(['doctor','patient']);} public function destroy(Review $review){$review->delete();return ['message'=>'Удалено'];}}
