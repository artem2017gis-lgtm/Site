<?php
namespace App\Http\Controllers\Admin;
use App\Models\Doctor; use Illuminate\Http\Request;
class ScheduleController extends \App\Http\Controllers\Controller {public function index(Doctor $doctor){return $doctor->schedules()->orderBy('weekday')->get();} public function update(Request $r,Doctor $doctor){$items=$r->validate(['schedules'=>'required|array','schedules.*.weekday'=>'required|integer|between:0,6','schedules.*.start_time'=>'required','schedules.*.end_time'=>'required','schedules.*.slot_duration'=>'required|integer|min:5']);$doctor->schedules()->delete();foreach($items['schedules'] as $item)$doctor->schedules()->create($item);return $doctor->load('schedules');}}
