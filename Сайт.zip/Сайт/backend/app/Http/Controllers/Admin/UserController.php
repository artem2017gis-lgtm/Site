<?php
namespace App\Http\Controllers\Admin;
use App\Models\User; use Illuminate\Http\Request;
class UserController extends \App\Http\Controllers\Controller {public function index(Request $r){return User::when($r->search,fn($q,$v)=>$q->where(fn($x)=>$x->where('name','like',"%$v%")->orWhere('email','like',"%$v%")))->latest()->paginate(20);} public function update(Request $r,User $user){$r->validate(['role'=>'required|in:patient,admin']);if($r->user()->is($user))return response()->json(['message'=>'Нельзя изменить собственную роль'],422);$user->update(['role'=>$r->role]);return $user;} public function destroy(Request $r,User $user){if($r->user()->is($user))return response()->json(['message'=>'Нельзя удалить собственный аккаунт'],422);$user->delete();return ['message'=>'Удалено'];}}
