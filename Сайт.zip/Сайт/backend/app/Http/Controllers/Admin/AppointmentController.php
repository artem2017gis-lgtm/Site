<?php
namespace App\Http\Controllers\Admin;
use App\Models\Appointment; use Illuminate\Http\Request;
class AppointmentController extends \App\Http\Controllers\Controller {public function index(Request $r){return Appointment::with(['doctor.specialty','patient'])->when($r->status,fn($q,$v)=>$q->where('status',$v))->when($r->date,fn($q,$v)=>$q->whereDate('date',$v))->latest('date')->paginate(20);} public function update(Request $r,Appointment $appointment){$appointment->update($r->validate(['status'=>'required|in:new,confirmed,done,canceled','complaint'=>'nullable|string']));return $appointment->load(['doctor','patient']);}}
