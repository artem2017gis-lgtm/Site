<?php namespace App\Models; use Illuminate\Database\Eloquent\Model;
class Schedule extends Model {public $timestamps=false; protected $fillable=['doctor_id','weekday','start_time','end_time','slot_duration']; public function doctor(){return $this->belongsTo(Doctor::class);}}
