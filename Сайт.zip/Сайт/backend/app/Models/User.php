<?php namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable; use Laravel\Sanctum\HasApiTokens; use Illuminate\Notifications\Notifiable;
class User extends Authenticatable {use HasApiTokens,Notifiable; protected $fillable=['name','email','password','phone','birth_date','role']; protected $hidden=['password','remember_token']; protected $casts=['birth_date'=>'date']; public function appointments(){return $this->hasMany(Appointment::class,'patient_id');} public function reviews(){return $this->hasMany(Review::class,'patient_id');} }
