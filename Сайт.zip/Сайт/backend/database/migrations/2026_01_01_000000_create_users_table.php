<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration { public function up(){Schema::create('users',function(Blueprint $t){$t->id();$t->string('name');$t->string('email')->unique();$t->string('password');$t->string('phone')->nullable();$t->date('birth_date')->nullable();$t->enum('role',['patient','admin'])->default('patient');$t->timestamps();});} public function down(){Schema::dropIfExists('users');}};

