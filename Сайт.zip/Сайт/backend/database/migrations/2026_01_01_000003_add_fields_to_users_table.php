<?php
use Illuminate\Database\Migrations\Migration; use Illuminate\Database\Schema\Blueprint; use Illuminate\Support\Facades\Schema;
return new class extends Migration {public function up(){Schema::table('users',function(Blueprint $t){$t->string('phone')->nullable()->after('password');$t->date('birth_date')->nullable()->after('phone');$t->enum('role',['patient','admin'])->default('patient')->after('birth_date');});}public function down(){Schema::table('users',function(Blueprint $t){$t->dropColumn(['phone','birth_date','role']);});}};
