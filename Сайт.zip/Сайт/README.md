# MedCare

Полноценный медицинский центр: публичный каталог врачей, авторизация Sanctum, онлайн-запись со свободными слотами, личный кабинет пациента и административный API.

## Запуск

```powershell
cd backend
copy .env.example .env
composer install
php artisan key:generate
php artisan migrate --seed
php artisan serve
```

В другом терминале:

```powershell
cd frontend
npm install
npm run dev
```

Адрес frontend: http://localhost:5173

### Аккаунты
- Администратор: `admin@medcare.ru` / `password`
- Пациент: `ivanov@mail.ru` / `password`
